package com.cg.employeemanagement.services;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.employeemanagement.dao.AdminDao;
import com.cg.employeemanagement.dao.AdminDaoImpl;
import com.cg.employeemanagement.dto.Employee;

public class AdminServiceImpl implements AdminService {

	AdminDao adminDao = new AdminDaoImpl();

	@Override
	public boolean addEmployee(Employee emp) {
		return adminDao.addEmployee(emp);
	}

	@Override
	public boolean deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.deleteEmployeeById(empId);
	}

	@Override
	public boolean modifyEmployeeName(int empId, String empName) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeName(empId, empName);
	}

	@Override
	public boolean modifyEmployeeSalary(int empId, float empSal) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeSalary(empId, empSal);
	}

	@Override
	public boolean modifyEmployeeDepartmentId(int empId, int deptId) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeDepartmentId(empId, deptId);
	}

	@Override
	public boolean modifyEmployeeDOB(int empId, LocalDate dob) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeDOB(empId, dob);
	}

	@Override
	public boolean modifyEmployeeContactNumber(int empId, Long empContactNumber) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeContactNumber(empId, empContactNumber);
	}

	@Override
	public boolean modifyEmployeeManagerId(int empId, int empManagerId) {
		// TODO Auto-generated method stub
		return adminDao.modifyEmployeeManagerId(empId, empManagerId);
	}

	
	@Override
	public Employee searchEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployeeById(empId);
	}

	@Override
	public List<Employee> searchEmployessByName(String name) {
		// TODO Auto-generated method stub
		return adminDao.searchEmployessByName(name);
	}
	
	@Override
	public List<Employee> displayEmployees() {
		// TODO Auto-generated method stub
		return adminDao.displayEmployees();
	}
	public boolean isValidPhone(String phone,String phonePattern)
	{
		if(Pattern.matches(phonePattern,phone))
			return true;
			else
			{
//			System.out.println("Wrong format");
			return false;
			}
	}
	public boolean isValidName(String name,String namePattern)
	{
		if(Pattern.matches(namePattern,name))
			return true;
			else
			{
//			System.out.println("Wrong format");
			return false;
			}
	}
	public boolean isValidDate(LocalDate dob)
	{
		if(dob.compareTo(LocalDate.now())>0)
		{
			return false;
		}
		else
			return true;
		
	}

}

package com.cg.employeemanagement.services;

import java.util.regex.Pattern;

import com.cg.employeemanagement.dao.LoginDao;
import com.cg.employeemanagement.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService{

	private LoginDao loginDao=new LoginDaoImpl();
	@Override
	public boolean validate(String userName, String password, int userRole) {
		
		return loginDao.validate(userName, password, userRole);
	}
	

}

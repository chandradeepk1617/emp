package com.cg.employeemanagement.pl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.LoginDao;
import com.cg.employeemanagement.dao.LoginDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.exception.EmpException;
import com.cg.employeemanagement.services.AdminService;
import com.cg.employeemanagement.services.AdminServiceImpl;
import com.cg.employeemanagement.services.EmpService;
import com.cg.employeemanagement.services.EmpServiceImpl;
import com.cg.employeemanagement.services.LoginService;
import com.cg.employeemanagement.services.LoginServiceImpl;
import com.cg.employeemanagement.services.ManagerService;
import com.cg.employeemanagement.services.ManagerServiceImpl;



public class EmployeeManagementDemo {

	public static void main(String[] args) {
		String phonePattern = "[^0][0-9]{9}";
		String namePattern = "[A-Z]{1,1}[a-z]{2,25}";


		System.out.println("Login types:\n"
				+ "\tEnter 1 for : Admin \n "
				+ "\tEnter 2 for : Manager\n "
				+ "\tEnter 3 for : Employee");
		int loginChoice;
		int choice;
		int flag=0;
		LoginService loginService =new LoginServiceImpl();
		Scanner scanner=new Scanner(System.in);
		loginChoice=scanner.nextInt();
		String userName;
		String password;
		boolean valid;
		System.out.println("Enter your User Name:");
		
		userName=scanner.next();
		System.out.println("Enter your password:");
		password=scanner.next();
		valid=loginService.validate(userName, password,loginChoice);
		System.out.println(valid);
		if(valid && loginChoice==1)
		{
			System.out.println("Admin:\n"
					+ "\t1.Add Employee\n"
					+ "\t2.Delete Employee\n"
					+ "\t3.Modify employee By Id\n"
					+ "\t4.Search employee by Id\n"
					+ "\t5.Search employee by name\n"
					+ "\t6.display all the employees");
			
			choice=scanner.nextInt();
			
			AdminService adminService=new AdminServiceImpl();
			
			switch(choice)
			{
				case 1:
					Employee emp;
					System.out.println("Enter Employee Name:");
					String empName=scanner.nextLine();
					//scanner.nextLine();
					while(flag!=1)
			    	{
						empName=scanner.nextLine();
						if(adminService.isValidName(empName,namePattern))
			    		flag=1;
			    	else
			    	{
			    		System.out.println("Name must start with a capital letter And must have atleast 3 characters");
			    		System.out.println("Enter Name Again");
			    	}
			    	}
					flag=0;
					
					System.out.println("Enter Employee Salary");
					float empSalary=scanner.nextFloat();
					System.out.println("Enter Employee Department Id");
					int empDeptId=scanner.nextInt();
					System.out.println("Enter employee date of birth in the format yyyy mm dd");
					LocalDate empDOB=null;
					while(flag!=1)
					{
					System.out.println("Enter year");
					int year=scanner.nextInt();
					System.out.println("Enter month");
					int month=scanner.nextInt();
					System.out.println("Enter date");
					int dayOfMonth=scanner.nextInt();
					empDOB=LocalDate.of(year, month, dayOfMonth);
					if(adminService.isValidDate(empDOB))
						flag=1;
					else
					{
						System.out.println("Date of birth cannot be after the present date");
						System.out.println("Emter Date of birth again");
					}
					}
					flag=0;
					System.out.println("Enter Employee Contact Number");
					Long empContactNumber=0L;
					while(flag!=1)
			    	{
						empContactNumber=scanner.nextLong();
						if(adminService.isValidPhone(String.valueOf(empContactNumber),phonePattern))
			    		flag=1;
			    	else
			    	{
			    		System.out.println("Contact number must have 10 digits and does not start with 0");
			    		System.out.println("Enter Contact number Again");
			    	}
			    	}
					flag=0;

					System.out.println("Enter Employee Manager Id");
					int empManagerId=scanner.nextInt();
					emp=new Employee(empName,empSalary,empDeptId,empDOB,empContactNumber,empManagerId,22);
					boolean status=adminService.addEmployee(emp);
					if(status)
					{
						System.out.println("Employee is added successfully");
					}
					else
					{
						throw new EmpException("error in adding the new employee to the database");
					}
					break;
					
				case 2:
					System.out.println("Enter Employee Id for deletion");
					int empDeleteId=scanner.nextInt();
					boolean deletionStatus=adminService.deleteEmployeeById(empDeleteId);
					if(deletionStatus)
					{
						System.out.println("Employee is deleted Sucessfully");
					}
					else
					{
						throw new EmpException("error in deleting the employee from database");
					}
					break;
				case 3:
					//Im writing code for only name modification as of now
					System.out.println("Enter Employee Id for Modification");
					int empToBeModifiedId=scanner.nextInt();
					System.out.println("\nEnter 1: to update name\n"
							+"Enter 2: to update Salary\n"
							+"Enter 3: to update Department id\n"
							+"Enter 4: to update Date of Birth\n"
							+"Enter 5: to update Contact Number\n"
							+"Enter 6: to update Manager Id\n");
					int modifyChoice=scanner.nextInt();
					boolean bool;
					switch(modifyChoice)
					{
					case 1:
						flag=0;
						System.out.println("Enter the new Name");
						String newName=scanner.nextLine();
						//scanner.nextLine();
						while(flag!=1)
				    	{
							newName=scanner.nextLine();
							if(adminService.isValidName(newName,namePattern))
				    		flag=1;
				    	else
				    	{
				    		System.out.println("Name must start with a capital letter And must have atleast 3 characters");
				    		System.out.println("Enter Name Again");
				    	}
				    	}
						flag=0;
						bool = adminService.modifyEmployeeName(empToBeModifiedId, newName);
						break;
					case 2:
						System.out.println("Enter the new Salary");
						float newSal=scanner.nextFloat();
						bool = adminService.modifyEmployeeSalary(empToBeModifiedId, newSal);
						break;
					case 3:
						System.out.println("Enter the new Department Id");
						int newdeptId=scanner.nextInt();
						bool = adminService.modifyEmployeeDepartmentId(empToBeModifiedId, newdeptId);
						break;
					case 4:
						System.out.println("Enter the correct Date Of Birth");
						LocalDate newDOB=null;
						int correctYear=0;
						int correctMonth=0;
						int correctDayOfMonth=0;
						while(flag!=1)
						{
						System.out.println("Enter year");
					    correctYear=scanner.nextInt();
						System.out.println("Enter month");
						correctMonth=scanner.nextInt();
						System.out.println("Enter date");
						correctDayOfMonth=scanner.nextInt();;
						if(adminService.isValidDate(newDOB))
							flag=1;
						else
						{
							System.out.println("Date of birth cannot be after the present date");
							System.out.println("Emter Date of birth again");
						}
						}
						flag=0;
					 newDOB=LocalDate.of(correctYear, correctMonth, correctDayOfMonth);
						bool = adminService.modifyEmployeeDOB(empToBeModifiedId, newDOB);
						break;
					case 5:
						System.out.println("Enter the new Contact Number");
						Long newContactNumber=0L;
						while(flag!=1)
				    	{
							newContactNumber=scanner.nextLong();
							if(adminService.isValidPhone(String.valueOf(newContactNumber),phonePattern))
				    		flag=1;
				    	else
				    	{
				    		System.out.println("Contact number must have 10 digits and does not start with 0");
				    		System.out.println("Enter Contact number Again");
				    	}
				    	}
						flag=0;
						
						bool = adminService.modifyEmployeeContactNumber(empToBeModifiedId, newContactNumber);
						break;
					case 6:
						System.out.println("Enter the new Manager's Id");
						int newManagerId=scanner.nextInt();
						bool = adminService.modifyEmployeeManagerId(empToBeModifiedId, newManagerId);
						break;
					}
					break;
					
				case 4:
					System.out.println("Enter Employee Id for searching");
					int empIdToBESearched=scanner.nextInt();
					Employee searchEmployee=adminService.searchEmployeeById(empIdToBESearched);
					if(searchEmployee==null)
						System.out.println("employee with id"+empIdToBESearched+" not found");
					else
						
					System.out.println("The employee details are: "+searchEmployee);
					break;
					
				case 5:
					System.out.println("Enter Employee name for searching");
					String empSearchByName=scanner.next();
					List<Employee> employeeList=adminService.searchEmployessByName(empSearchByName);
					if(employeeList==null)
						System.out.println("employee with name"+empSearchByName+" not found");
					else
					{
					for(Employee resultEmp:employeeList)
					{
						System.out.println(resultEmp);
					}
					}
					break;
				case 6:
					List<Employee> empTotalList=adminService.displayEmployees();
					for(Employee totalEmp:empTotalList)
					{
						System.out.println(totalEmp);
					}
					break;
				default:
						System.out.println("Exit");
			}
		}
		else if(valid && loginChoice==2){
			do
			{
				System.out.println("Manager\n"
						+ "\t1.Search By employee Id\n"
						+ "\t2.Search employee by name\n"
						+ "\t3.Display own details\n"
						+ "\t4.Display employees under them\n"
						+ "\t5.Show leaves applied by employees\n"
						+ "\t6.Accept leave\n"
						+ "\t7.Reject leave"
						+ "\t8. ");
				
				choice=scanner.nextInt();
				
				ManagerService managerService=new ManagerServiceImpl();
				switch(choice)
				{
					case 1:
						System.out.println("Enter employee id to be searched");
						int empSearchId=scanner.nextInt();
						
						Employee searchedEmp=managerService.searchEmployeeById(empSearchId);
						if(searchedEmp==null)
						System.out.println("Employee with id "+empSearchId+" not found");
							else
							System.out.println("The employee details are: \n"+searchedEmp);
						break;
					case 2:
						System.out.println("Enter Employee name to be searched");
						String empName=scanner.next();
						List<Employee> empTotalList=managerService.searchEmployeeByName(empName);
						if(empTotalList==null)
						{
							System.out.println("Employee with name "+empName+" not Found");
						}
						else
						{
						for(Employee result:empTotalList)
						{
							System.out.println(result);
						}
						}
						break;
						
					case 3:
						Employee empOwnDetails = managerService.displayOwnDetails(userName);
						
						System.out.println(empOwnDetails);
						break;
						
					case 4:
						List<Employee> subEmpList = managerService.displaySubEmployees(userName);
						if(subEmpList==null)
						{
							System.out.println("no Employees Are present under "+userName);
						}
						else
						{
						for(Employee list:subEmpList)
						{
							System.out.println(list);
						}
						}
						break;
						
					case 5:
						List<Leave> leaveList=managerService.showLeavesApplied(userName);
						if(leaveList==null)
						{
							System.out.println("No leave details are present");
						}
						else
						{
						for(Leave leave:leaveList)
						{
							System.out.println(leave);
						}
						}
						break;
						
					case 6:
						System.out.println("Enter leave id to be accepted");
						int leaveId=scanner.nextInt();
						boolean leaveAcceptStatus=managerService.accept(leaveId);
						if(leaveAcceptStatus)
						{
							System.out.println("Leave accepted sucessfully");
						}
						break;
					case 7:
						System.out.println("Enter leave id for rejection");
						int leaveId2=scanner.nextInt();
						System.out.println("Enter reason for rejection");
						String reason=scanner.next();
						boolean rejectStatus=managerService.reject(leaveId2, reason);
						if(rejectStatus)
						{
							System.out.println("Sucessfully rejected");
						}
						break;
					default:
						System.out.println("Exit/Logout");
						
				}
			}while(choice!=7);
			
		}
		else if(valid && loginChoice==3)
		{
			System.out.println("Employee\n1.Search EMployee By Id\n2.Search employee By Name\n3.Display their own details\n4.change account password\n5.check attendance\n6.apply for leave\n7.Edit leave\n8.search any leave\n9.cancel any leave");
			int employeeChoice=scanner.nextInt();
			EmployeeDao employeeDto=new EmployeeDaoImpl();
			EmpService empService = new EmpServiceImpl();
			switch(employeeChoice)
			{
				case 1:
					System.out.println("Enter employee id to be searched");
					int empSearchId=scanner.nextInt();
					Employee searchedEmp=employeeDto.searchEmployeeById(empSearchId);
					if(searchedEmp==null)
						System.out.println("Employee with id "+empSearchId+" not Present");
					else
					{
					System.out.println("The employee details are: "+searchedEmp);
					}
					break;
				case 2:
					System.out.println("Enter Employee name to be searched");
					String empName=scanner.next();
					List<Employee> empTotalList=employeeDto.searchEmployeeByName(empName);
					if(empTotalList==null)
					{
						System.out.println("Employee with name "+empName+" not found");
					}
					else
					{
					for(Employee result:empTotalList)
					{
						System.out.println(result);
					}
					}
					break;
				case 3:
					Employee empOwnDetails=employeeDto.displayEmpDetails();
					System.out.println(empOwnDetails);
					break;
				case 4:
					System.out.println("Enter old password");
					String oldPassword=scanner.next();
					System.out.println("Enter new password");
					String newPassword=scanner.next();
					boolean pwdChangeStatus=employeeDto.changeAccountPassword(oldPassword, newPassword);
					if(pwdChangeStatus)
					{
						System.out.println("changed successfully");
					}
					break;
				case 5:
					int attendance=employeeDto.checkAttendance();
					System.out.println("Attendance is: "+attendance);
					break;
				case 6:
					System.out.println("Enter from date in the format yyyy mm dd");
					LocalDate fDate=null;
					LocalDate tDate=null;
					LocalDate today=null;
					flag=0;
					while(flag!=1)
					{
					System.out.println("enter year");
						int fromYear=scanner.nextInt();
						System.out.println("Enter months");
					int fromMonth=scanner.nextInt();
					System.out.println("Enter Days");
					int fromDate=scanner.nextInt();
					
					 fDate=LocalDate.of(fromYear, fromMonth, fromDate);
					 if(empService.validateFromDate(fDate))
					 {
						 flag=1;
					 }
					 else
					 {
						 System.out.println("From date cannont be before present date or cannot be after 45 days");
					 System.out.println("Enter From date again in the format yyyy mm dd");
					 }
					}
					flag=0;
					 System.out.println("Enter to date in format yyyy mm dd");
					while(flag!=1)
					{
						System.out.println("Enter year");
					 int toYear=scanner.nextInt();
					 System.out.println("Enter month");
					int toMonth=scanner.nextInt();
					System.out.println("Enter day");
					int toDate=scanner.nextInt();
				 tDate=LocalDate.of(toYear, toMonth, toMonth);
				 today=LocalDate.now();
				 if(empService.validateTODate(fDate,tDate))
				 {
					 flag=1;
				 }
				 else
				 {
					 System.out.println("To date can't be before From date and To date can't be after 10 from from date");
					 System.out.println("Enter to date in format yyyy mm dd");
				 }
					}	
				 int empId=0;//write code to get access present employee id;
					
					Leave leave=new Leave(fDate,tDate,today,false,empId,0);
					boolean leaveStatus=employeeDto.addLeave(leave);
					if(leaveStatus)
					{
						System.out.println("Sucessfully");
					}
					break;
				case 7:
					System.out.println("Enter leave id to modify leave");
					int leaveId=scanner.nextInt();
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear1=scanner.nextInt();
					int fromMonth1=scanner.nextInt();
					int fromDate1=scanner.nextInt();
					LocalDate fDate1=LocalDate.of(fromYear1, fromMonth1, fromDate1);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear1=scanner.nextInt();
					int toMonth1=scanner.nextInt();
					int toDate1=scanner.nextInt();
					LocalDate tDate1=LocalDate.of(toYear1, toMonth1, toMonth1);
					LocalDate today1=LocalDate.now();
					Leave editedLeave=employeeDto.editLeave(leaveId, fDate1, tDate1);
					System.out.println("leave modified to: "+editedLeave);
					break;
					
					
					
			}
		}
		else
		{
			System.out.println("Invalid login credentials");
		}
		
	}

}

package com.cg.employeemanagement.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Leave;



public class LeavesStaticDB {
	private List<Leave> leavesList=new ArrayList<Leave>(); 
	public List<Leave> getLeavesList()
	{
		leavesList.add(new Leave(LocalDate.of(2020, 04, 12),LocalDate.of(2020, 04, 16),
				LocalDate.now(),false,1,2));
		leavesList.add(new Leave(LocalDate.of(2020, 05, 12),LocalDate.of(2020, 05, 16),
				LocalDate.now(),false,2,1));
		return leavesList;
	}
}

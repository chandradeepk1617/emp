package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.LeaveResponse;

public class LeaveResponseStaticDB {
	List<LeaveResponse> leaveResponse = new ArrayList<>();
	
	public LeaveResponseStaticDB() {
		super();
	}

	public boolean add(int leaveid,String response)
	{
		leaveResponse.add(new LeaveResponse(leaveid, response));
		return true;
	}

}
